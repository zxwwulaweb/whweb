-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2016 年 04 月 19 日 08:41
-- 服务器版本: 5.5.8
-- PHP 版本: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `whweb`
--

-- --------------------------------------------------------

--
-- 表的结构 `yp_admins`
--

CREATE TABLE IF NOT EXISTS `yp_admins` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `email` char(50) NOT NULL,
  `password` char(32) NOT NULL,
  `ip` char(20) NOT NULL,
  `validate` tinyint(4) NOT NULL,
  `createtmie` datetime NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `yp_admins`
--

INSERT INTO `yp_admins` (`userid`, `email`, `password`, `ip`, `validate`, `createtmie`) VALUES
(1, 'admin', '9557b4017f841671cdf122ceda233b37', '127.0.0.1', 1, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- 表的结构 `yp_article`
--

CREATE TABLE IF NOT EXISTS `yp_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `partent_id` int(11) NOT NULL COMMENT '父类id',
  `cate_id` int(11) NOT NULL COMMENT '分类id',
  `title` varchar(512) NOT NULL COMMENT '标题',
  `content` text NOT NULL COMMENT '内容',
  `createtime` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `yp_article`
--

INSERT INTO `yp_article` (`id`, `partent_id`, `cate_id`, `title`, `content`, `createtime`, `status`) VALUES
(1, 0, 1, 'test', 'this is a test', 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `yp_article_cate`
--

CREATE TABLE IF NOT EXISTS `yp_article_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `partent` tinyint(4) NOT NULL,
  `title` varchar(256) NOT NULL,
  `createtime` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `yp_article_cate`
--

INSERT INTO `yp_article_cate` (`id`, `partent`, `title`, `createtime`, `status`) VALUES
(1, 0, '分类1', 5165161, 1);

-- --------------------------------------------------------

--
-- 表的结构 `yp_article_collect`
--

CREATE TABLE IF NOT EXISTS `yp_article_collect` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `yp_article_collect`
--


-- --------------------------------------------------------

--
-- 表的结构 `yp_article_comment`
--

CREATE TABLE IF NOT EXISTS `yp_article_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` tinyint(4) NOT NULL,
  `article_id` tinyint(4) NOT NULL,
  `content` varchar(1024) NOT NULL,
  `createtime` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `yp_article_comment`
--

INSERT INTO `yp_article_comment` (`id`, `uid`, `article_id`, `content`, `createtime`, `status`) VALUES
(1, 2, 1, '不错不错', 1460950103, 1),
(2, 2, 1, '不错不错', 1460950176, 1);

-- --------------------------------------------------------

--
-- 表的结构 `yp_community_facilities`
--

CREATE TABLE IF NOT EXISTS `yp_community_facilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `createtime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `yp_community_facilities`
--


-- --------------------------------------------------------

--
-- 表的结构 `yp_house_type`
--

CREATE TABLE IF NOT EXISTS `yp_house_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(128) NOT NULL,
  `createtime` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `yp_house_type`
--

INSERT INTO `yp_house_type` (`id`, `type`, `createtime`, `status`) VALUES
(1, '学生公寓', 1475214523, 1);

-- --------------------------------------------------------

--
-- 表的结构 `yp_links`
--

CREATE TABLE IF NOT EXISTS `yp_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `url` varchar(256) NOT NULL,
  `img` varchar(200) NOT NULL,
  `sort` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `yp_links`
--


-- --------------------------------------------------------

--
-- 表的结构 `yp_member`
--

CREATE TABLE IF NOT EXISTS `yp_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL COMMENT '密码',
  `onlykey` varchar(32) NOT NULL COMMENT '本次登录唯一码',
  `nickname` varchar(128) NOT NULL COMMENT '昵称',
  `email` varchar(64) NOT NULL COMMENT '邮箱',
  `head` varchar(128) NOT NULL COMMENT '头像',
  `phone` varchar(128) NOT NULL COMMENT '电话',
  `createtime` varchar(128) NOT NULL COMMENT '创建时间',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '1表示可用0表示不可用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `yp_member`
--

INSERT INTO `yp_member` (`id`, `password`, `onlykey`, `nickname`, `email`, `head`, `phone`, `createtime`, `status`) VALUES
(1, '12345656156165165161', '0', 'test', '651651@qq.com', 'dsdsd', '61651615', '1561616', 1),
(2, 'e10adc3949ba59abbe56e057f20f883e', '3327904whblb571452f56aa1e', 'andy', '1019034564@qq.com', '', '', '', 1),
(7, 'e10adc3949ba59abbe56e057f20f883e', '0', '', '9849849@qq.com', '', '', '1459936678', 1);

-- --------------------------------------------------------

--
-- 表的结构 `yp_rentals_collect`
--

CREATE TABLE IF NOT EXISTS `yp_rentals_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '收藏者id',
  `info_id` int(11) NOT NULL COMMENT '租房信息id',
  `createtime` int(11) NOT NULL COMMENT '收藏时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `yp_rentals_collect`
--


-- --------------------------------------------------------

--
-- 表的结构 `yp_rentals_comment`
--

CREATE TABLE IF NOT EXISTS `yp_rentals_comment` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL COMMENT '评论人id',
  `rentalsid` int(11) NOT NULL COMMENT '房租信息id',
  `content` varchar(512) NOT NULL COMMENT '内容',
  `createtime` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `yp_rentals_comment`
--


-- --------------------------------------------------------

--
-- 表的结构 `yp_rentals_info`
--

CREATE TABLE IF NOT EXISTS `yp_rentals_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL,
  `country_id` int(11) NOT NULL COMMENT '国家id',
  `city_id` int(11) NOT NULL COMMENT '城市id',
  `address` varchar(256) NOT NULL COMMENT '地址',
  `zip_code` varchar(28) NOT NULL COMMENT '邮编',
  `min_lease` varchar(64) NOT NULL COMMENT '最短租期',
  `house_type` int(11) NOT NULL COMMENT '房子类型',
  `room_num` int(11) NOT NULL COMMENT '居室数',
  `area` varchar(64) NOT NULL COMMENT '面积',
  `rent` varchar(256) NOT NULL COMMENT '租金',
  `deposit` varchar(28) NOT NULL COMMENT '押金',
  `room_facilities` varchar(256) NOT NULL COMMENT '房间设施',
  `community_facilities` varchar(256) NOT NULL COMMENT '小区设施',
  `periphery` varchar(256) NOT NULL COMMENT '周边',
  `description` varchar(512) NOT NULL COMMENT '描述',
  `begin_time` int(11) NOT NULL COMMENT '开始时间',
  `createtime` int(11) NOT NULL COMMENT '发布时间',
  `updatetime` int(11) NOT NULL COMMENT '更新时间',
  `status` int(11) NOT NULL COMMENT '1有效0无效',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `yp_rentals_info`
--

INSERT INTO `yp_rentals_info` (`id`, `title`, `country_id`, `city_id`, `address`, `zip_code`, `min_lease`, `house_type`, `room_num`, `area`, `rent`, `deposit`, `room_facilities`, `community_facilities`, `periphery`, `description`, `begin_time`, `createtime`, `updatetime`, `status`) VALUES
(1, '最新房屋出租', 1, 2, '厦门市思明区明发园', '363100', '2个月', 1, 2, '100', '2000', '1000', '1,2', '1,2,3', '蔡塘广场，万达广场', '这里交通便捷', 2016, 1460618880, 1460618880, 1);

-- --------------------------------------------------------

--
-- 表的结构 `yp_room_facilities`
--

CREATE TABLE IF NOT EXISTS `yp_room_facilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `createtime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `yp_room_facilities`
--

INSERT INTO `yp_room_facilities` (`id`, `name`, `createtime`) VALUES
(1, '空调', 1765145),
(2, '热水器', 17456214);

-- --------------------------------------------------------

--
-- 表的结构 `yp_shelter`
--

CREATE TABLE IF NOT EXISTS `yp_shelter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `cityid` int(11) NOT NULL,
  `content` varchar(512) NOT NULL,
  `img` varchar(1024) NOT NULL,
  `createtime` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `yp_shelter`
--

INSERT INTO `yp_shelter` (`id`, `uid`, `cityid`, `content`, `img`, `createtime`, `status`) VALUES
(1, 2, 1, '2fdfdsf', 'dsds', 0, 1),
(2, 2, 1, '求收留啊啊啊', 'fdfdovgfdnbidobaiscn', 1461038597, 1);

-- --------------------------------------------------------

--
-- 表的结构 `yp_shelter_collect`
--

CREATE TABLE IF NOT EXISTS `yp_shelter_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '发布人id',
  `sid` int(11) NOT NULL COMMENT '收藏人id',
  `shelterid` int(11) NOT NULL COMMENT '收留说说id',
  `createtime` int(11) NOT NULL COMMENT '收藏时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `yp_shelter_collect`
--

INSERT INTO `yp_shelter_collect` (`id`, `uid`, `sid`, `shelterid`, `createtime`) VALUES
(1, 2, 0, 1, 1461036393),
(2, 2, 0, 0, 1461036739);

-- --------------------------------------------------------

--
-- 表的结构 `yp_shelter_comment`
--

CREATE TABLE IF NOT EXISTS `yp_shelter_comment` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL COMMENT '评论人id',
  `sid` int(11) NOT NULL COMMENT '回复人id',
  `shelterid` int(11) NOT NULL COMMENT '说说id',
  `content` varchar(64) NOT NULL COMMENT '评论内容',
  `createtime` int(11) NOT NULL COMMENT '评论时间',
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `yp_shelter_comment`
--

INSERT INTO `yp_shelter_comment` (`id`, `uid`, `sid`, `shelterid`, `content`, `createtime`, `status`) VALUES
(0, 2, 1, 1, '啦啦啦啦', 1461036883, 1),
(0, 2, 1, 1, '啦啦啦啦', 1461037195, 1);
